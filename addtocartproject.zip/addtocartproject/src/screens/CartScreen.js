import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Toast from 'react-native-toast-message';
import { useIsFocused } from '@react-navigation/native';

const CartScreen = ({ navigation }) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [processingCheckout, setProcessingCheckout] = useState(false);
  const subscriptionRef = useRef(null);
  const [userId, setUserId] = useState(null);
  const isFocused = useIsFocused();

  useEffect(() => {
    if (isFocused) {
      initialize();
    }

    return () => {
      if (subscriptionRef.current) {
        supabase.removeChannel(subscriptionRef.current);
        subscriptionRef.current = null;
      }
    };
  }, [isFocused]);

  const initialize = async () => {
    try {
      setLoading(true);
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;

      if (!user) {
        navigation.navigate('Login');
        return;
      }

      setUserId(user.id);
      await fetchCartItems(user.id);
      setupRealtimeSubscription(user.id);
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Error', text2: error.message });
      setLoading(false);
    }
  };

  const fetchCartItems = async (uid) => {
    try {
      const { data, error } = await supabase
        .from('carts')
        .select(`
          id,
          quantity,
          products:product_id (
            id,
            name,
            price,
            image
          )
        `)
        .eq('user_id', uid);

      if (error) throw error;
      setCartItems(data || []);
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Error', text2: error.message });
    } finally {
      setLoading(false);
    }
  };

  const setupRealtimeSubscription = (uid) => {
    if (subscriptionRef.current) {
      supabase.removeChannel(subscriptionRef.current);
    }

    subscriptionRef.current = supabase
      .channel('cart_items_updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'carts',
          filter: `user_id=eq.${uid}`,
        },
        () => {
          fetchCartItems(uid);
        }
      )
      .subscribe();
  };

  useEffect(() => {
    calculateTotal();
  }, [cartItems]);

  const calculateTotal = () => {
    const sum = cartItems.reduce((acc, item) => {
      if (item.products?.price && item.quantity) {
        return acc + item.products.price * item.quantity;
      }
      return acc;
    }, 0);
    setTotal(sum);
  };

  const updateQuantity = useCallback(async (cartId, newQuantity) => {
    if (newQuantity < 1) {
      confirmRemoveItem(cartId);
      return;
    }

    setCartItems(prev =>
      prev.map(item =>
        item.id === cartId ? { ...item, quantity: newQuantity } : item
      )
    );

    try {
      const { error } = await supabase
        .from('carts')
        .update({ quantity: newQuantity })
        .eq('id', cartId);
      if (error) throw error;
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Error', text2: error.message });
      if (userId) fetchCartItems(userId);
    }
  }, [userId]);

  const confirmRemoveItem = (cartId) => {
    Alert.alert(
      'Remove Item',
      'Are you sure you want to remove this item from your cart?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => removeItem(cartId),
        },
      ]
    );
  };

  const removeItem = useCallback(async (cartId) => {
    setCartItems(prev => prev.filter(item => item.id !== cartId));

    try {
      const { error } = await supabase.from('carts').delete().eq('id', cartId);
      if (error) throw error;
      Toast.show({
        type: 'success',
        text1: 'Removed',
        text2: 'Item has been removed from your cart',
      });
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Error', text2: error.message });
      if (userId) fetchCartItems(userId);
    }
  }, [userId]);

  const handleCheckout = async () => {
    if (cartItems.length === 0) return;

    Alert.alert(
      'Confirm Checkout',
      `Your total is $${(total + 5.99).toFixed(2)}. Proceed with checkout?`,
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Confirm',
          onPress: async () => {
            setProcessingCheckout(true);
            try {
              // In a real app, you would process payment here
              // For now, we'll just clear the cart
              const { error } = await supabase
                .from('carts')
                .delete()
                .eq('user_id', userId);

              if (error) throw error;

              Toast.show({
                type: 'success',
                text1: 'Order Placed!',
                text2: 'Your order has been placed successfully',
              });
              
              // Clear local state
              setCartItems([]);
              setTotal(0);
              
              // Navigate to order confirmation or home screen
              navigation.navigate('Home');
            } catch (error) {
              Toast.show({
                type: 'error',
                text1: 'Checkout Failed',
                text2: error.message,
              });
            } finally {
              setProcessingCheckout(false);
            }
          },
        },
      ]
    );
  };

  const renderCartItem = ({ item }) => (
    <View style={styles.cartItem}>
      <Image source={{ uri: item.products?.image }} style={styles.itemImage} />
      <View style={styles.itemDetails}>
        <Text style={styles.itemName}>{item.products?.name}</Text>
        <Text style={styles.itemPrice}>${item.products?.price?.toFixed(2)}</Text>
        <View style={styles.quantityContainer}>
          <TouchableOpacity
            onPress={() => updateQuantity(item.id, item.quantity - 1)}
            style={styles.quantityButton}
          >
            <Icon name="remove" size={18} color="#333" />
          </TouchableOpacity>
          <Text style={styles.quantityValue}>{item.quantity}</Text>
          <TouchableOpacity
            onPress={() => updateQuantity(item.id, item.quantity + 1)}
            style={styles.quantityButton}
          >
            <Icon name="add" size={18} color="#333" />
          </TouchableOpacity>
        </View>
      </View>
      <TouchableOpacity 
        onPress={() => confirmRemoveItem(item.id)} 
        style={styles.removeButton}
      >
        <Icon name="delete" size={24} color="#ff6b6b" />
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-back" size={28} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Your Cart</Text>
        <View style={{ width: 28 }} />
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <Text>Loading cart...</Text>
        </View>
      ) : cartItems.length === 0 ? (
        <View style={styles.emptyCartContainer}>
          <Icon name="remove-shopping-cart" size={60} color="#ddd" />
          <Text style={styles.emptyCartText}>Your cart is empty</Text>
          <TouchableOpacity
            style={styles.continueShoppingButton}
            onPress={() => navigation.navigate('Home')}
          >
            <Text style={styles.continueShoppingText}>Continue Shopping</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <FlatList
            data={cartItems}
            renderItem={renderCartItem}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.cartList}
          />
          <View style={styles.summaryContainer}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Subtotal</Text>
              <Text style={styles.summaryValue}>${total.toFixed(2)}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Shipping</Text>
              <Text style={styles.summaryValue}>$5.99</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Total</Text>
              <Text style={styles.summaryTotal}>${(total + 5.99).toFixed(2)}</Text>
            </View>
            <TouchableOpacity 
              style={[styles.checkoutButton, processingCheckout && styles.disabledButton]}
              onPress={handleCheckout}
              disabled={processingCheckout}
            >
              <Text style={styles.checkoutButtonText}>
                {processingCheckout ? 'Processing...' : 'Proceed to Checkout'}
              </Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    backgroundColor: 'white',
  },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#333', marginTop: 30, },
  backButton: { padding: 8, marginTop: 30, },
  cartList: { padding: 16 },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  itemImage: { width: 80, height: 80, borderRadius: 8, marginRight: 12 },
  itemDetails: { flex: 1, justifyContent: 'center' },
  itemName: { fontSize: 16, fontWeight: '600', marginBottom: 4, color: '#333' },
  itemPrice: { fontSize: 16, fontWeight: 'bold', color: '#2e86de', marginBottom: 8 },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  quantityButton: { padding: 6, backgroundColor: '#f1f2f6' },
  quantityValue: { paddingHorizontal: 12, fontSize: 16 },
  removeButton: { padding: 8, alignSelf: 'center' },
  summaryContainer: {
    padding: 20,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryLabel: { fontSize: 16, color: '#666' },
  summaryValue: { fontSize: 16, fontWeight: '500' },
  summaryTotal: { fontSize: 18, fontWeight: 'bold', color: '#2e86de' },
  checkoutButton: {
    backgroundColor: '#2e86de',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  disabledButton: {
    backgroundColor: '#a0c4ff',
  },
  checkoutButtonText: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyCartContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyCartText: { fontSize: 18, color: '#888', marginVertical: 20 },
  continueShoppingButton: {
    backgroundColor: '#2e86de',
    padding: 16,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
  },
  continueShoppingText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
});

export default CartScreen;