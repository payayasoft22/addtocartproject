import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { supabase } from '../lib/supabase';
import Toast from 'react-native-toast-message';

const ProductDetailScreen = ({ route, navigation }) => {
  const { product } = route.params; // get product from navigation params
  const [quantity, setQuantity] = useState(1);

  const addToCart = async () => {
    try {
      // Get current logged-in user
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        Toast.show({
          type: 'error',
          text1: 'Not logged in',
          text2: 'Please log in to add items to cart.',
        });
        navigation.navigate('Login');
        return;
      }

      const userId = user.id;

      const { data: existingItem, error: fetchError } = await supabase
        .from('carts')
        .select('*')
        .eq('user_id', userId)
        .eq('product_id', product.id)
        .single();

      if ((!existingItem && !fetchError) || (fetchError && fetchError.code === 'PGRST116')) {
        // Insert new cart item
        const { error: insertError } = await supabase
          .from('carts')
          .insert([{ user_id: userId, product_id: product.id, quantity }]);
        if (insertError) throw insertError;
      } else if (existingItem) {
        // Update existing cart item quantity
        const { error: updateError } = await supabase
          .from('carts')
          .update({ quantity: existingItem.quantity + quantity })
          .eq('user_id', userId)
          .eq('product_id', product.id);
        if (updateError) throw updateError;
      }

      Toast.show({
        type: 'success',
        text1: 'Added to cart',
        text2: 'Item added successfully',
      });

      navigation.goBack();
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: error.message,
      });
    }
  };

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1);
  };

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* Header with back button */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Product Details</Text>
      </View>

      <Image source={{ uri: product.image }} style={styles.productImage} />

      <View style={styles.productDetails}>
        <Text style={styles.productName}>{product.name}</Text>
        <Text style={styles.productPrice}>${product.price.toFixed(2)}</Text>

        <View style={styles.quantityContainer}>
          <Text style={styles.quantityLabel}>Quantity:</Text>
          <View style={styles.quantityControls}>
            <TouchableOpacity onPress={decreaseQuantity} style={styles.quantityButton}>
              <Icon name="remove" size={20} color="#333" />
            </TouchableOpacity>
            <Text style={styles.quantityValue}>{quantity}</Text>
            <TouchableOpacity onPress={increaseQuantity} style={styles.quantityButton}>
              <Icon name="add" size={20} color="#333" />
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Description</Text>
        <Text style={styles.productDescription}>{product.description}</Text>

        <TouchableOpacity style={styles.addToCartButton} onPress={addToCart}>
          <Text style={styles.addToCartText}>
            Add to Cart - ${(product.price * quantity).toFixed(2)}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 15,
    backgroundColor: '#fff',
    elevation: 2, // shadow for Android
    shadowColor: '#000', // shadow for iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  backButton: {
    padding: 5,
    marginRight: 10,
    marginTop: 30,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginTop: 30,
  },
  productImage: { width: '100%', height: 300, resizeMode: 'cover' },
  productDetails: { padding: 20 },
  productName: { fontSize: 24, fontWeight: 'bold', marginBottom: 8, color: '#333' },
  productPrice: { fontSize: 22, fontWeight: 'bold', color: '#2e86de', marginBottom: 20 },
  quantityContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  quantityLabel: { fontSize: 16, marginRight: 15, color: '#666' },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
  },
  quantityButton: { padding: 10, backgroundColor: '#f1f2f6' },
  quantityValue: { paddingHorizontal: 15, fontSize: 16 },
  sectionTitle: { fontSize: 18, fontWeight: '600', marginBottom: 10, color: '#333' },
  productDescription: { fontSize: 16, lineHeight: 24, color: '#666', marginBottom: 30 },
  addToCartButton: {
    backgroundColor: '#2e86de',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  addToCartText: { color: 'white', fontSize: 18, fontWeight: 'bold' },
});

export default ProductDetailScreen;
