import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
  StyleSheet,
  SafeAreaView,
  TextInput,
  Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Toast from 'react-native-toast-message';
import { useNavigation, useIsFocused } from '@react-navigation/native';

const HomeScreen = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [cartCount, setCartCount] = useState(0);
  const subscriptionRef = useRef(null);
  const isFocused = useIsFocused();

  const navigation = useNavigation();

  useEffect(() => {
    if (isFocused) {
      fetchUser();
      fetchProducts();
    }

    return () => {
      if (subscriptionRef.current) {
        supabase.removeChannel(subscriptionRef.current);
        subscriptionRef.current = null;
      }
    };
  }, [isFocused]);

  const fetchUser = async () => {
    const { data: { user: currentUser }, error } = await supabase.auth.getUser();
    if (error) {
      console.error('Error fetching user:', error.message);
      return;
    }
    setUser(currentUser);
    if (currentUser) {
      fetchCartCount(currentUser.id);
      setupRealtimeSubscription(currentUser.id);
    } else {
      setCartCount(0);
      if (subscriptionRef.current) {
        supabase.removeChannel(subscriptionRef.current);
        subscriptionRef.current = null;
      }
    }
  };

  const fetchCartCount = async (userId) => {
    try {
      const { data, error } = await supabase
        .from('carts')
        .select('quantity')
        .eq('user_id', userId);

      if (error) throw error;

      const totalCount = data.reduce((acc, item) => acc + item.quantity, 0);
      setCartCount(totalCount);
    } catch (error) {
      console.error('Failed to fetch cart count:', error.message);
    }
  };

  const setupRealtimeSubscription = (userId) => {
    if (subscriptionRef.current) {
      supabase.removeChannel(subscriptionRef.current);
    }

    subscriptionRef.current = supabase
      .channel('cart_count_updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'carts',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          // Immediate update based on change type
          if (payload.eventType === 'INSERT') {
            setCartCount(prev => prev + payload.new.quantity);
          } else if (payload.eventType === 'UPDATE') {
            setCartCount(prev => prev + (payload.new.quantity - payload.old.quantity));
          } else if (payload.eventType === 'DELETE') {
            setCartCount(prev => prev - payload.old.quantity);
          }
          // Also fetch fresh count to ensure accuracy
          fetchCartCount(userId);
        }
      )
      .subscribe();
  };

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.from('products').select('*');
      if (error) throw error;
      setProducts(data);
      setFilteredProducts(data);
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Error', text2: error.message });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredProducts(products);
    } else {
      const filtered = products.filter((product) =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  }, [searchQuery, products]);

  const addToCart = async (productId) => {
  if (!user) {
    Toast.show({
      type: 'error',
      text1: 'Not logged in',
      text2: 'Please log in to add items to cart.',
    });
    return;
  }

  try {
    // Optimistic update
    setCartCount(prev => prev + 1);

    const userId = user.id;
    const { data: existingItem, error: fetchError } = await supabase
      .from('carts')
      .select('*')
      .eq('user_id', userId)
      .eq('product_id', productId)
      .single();

    if (fetchError && !existingItem) {
      await supabase
        .from('carts')
        .insert([{ user_id: userId, product_id: productId, quantity: 1 }]);
    } else if (existingItem) {
      await supabase
        .from('carts')
        .update({ quantity: existingItem.quantity + 1 })
        .eq('user_id', userId)
        .eq('product_id', productId);
    }

    Toast.show({
      type: 'success',
      text1: 'Added to cart',
      text2: 'Item has been added to your cart',
    });
  } catch (error) {
    // Rollback the optimistic update if there's an error
    setCartCount(prev => prev - 1);
    Toast.show({ type: 'error', text1: 'Error', text2: error.message });
  }
};

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          const { error } = await supabase.auth.signOut();
          if (error) {
            Toast.show({ type: 'error', text1: 'Logout Failed', text2: error.message });
          } else {
            Toast.show({
              type: 'success',
              text1: 'Logged out',
              text2: 'You have been logged out successfully',
            });
            setUser(null);
            setCartCount(0);
            if (subscriptionRef.current) {
              supabase.removeChannel(subscriptionRef.current);
              subscriptionRef.current = null;
            }
          }
        },
      },
    ]);
  };

  const renderProductItem = ({ item }) => (
    <TouchableOpacity
      style={styles.productCard}
      onPress={() => navigation.navigate('ProductDetail', { product: item })}
    >
      <Image source={{ uri: item.image }} style={styles.productImage} />
      <View style={styles.productInfo}>
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
        <Text style={styles.productDescription} numberOfLines={2}>
          {item.description}
        </Text>
      </View>
      <TouchableOpacity 
        style={styles.addToCartButton} 
        onPress={(e) => {
          e.stopPropagation();
          addToCart(item.id);
        }}
      >
        <Icon name="add-shopping-cart" size={20} color="white" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>ShopNow</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity 
            onPress={() => navigation.navigate('Cart')} 
            style={styles.iconButton}
          >
            <Icon name="shopping-cart" size={28} color="#333" />
            {cartCount > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{cartCount}</Text>
              </View>
            )}
          </TouchableOpacity>
          {user && (
            <TouchableOpacity onPress={handleLogout} style={styles.iconButton}>
              <Icon name="logout" size={28} color="#333" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search products..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <Icon name="search" size={24} color="#888" style={styles.searchIcon} />
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <Text>Loading products...</Text>
        </View>
      ) : (
        <FlatList
          data={filteredProducts}
          renderItem={renderProductItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.productList}
          numColumns={2}
          columnWrapperStyle={styles.columnWrapper}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 30,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  iconButton: {
    marginLeft: 16,
    position: 'relative',
  },
  cartBadge: {
    position: 'absolute',
    right: -6,
    top: -6,
    backgroundColor: '#ff3b30',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    zIndex: 10,
  },
  cartBadgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  searchContainer: { padding: 16, position: 'relative' },
  searchInput: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 12,
    paddingLeft: 45,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  searchIcon: { position: 'absolute', left: 30, top: 30 },
  productList: { paddingHorizontal: 8 },
  columnWrapper: { justifyContent: 'space-between', marginBottom: 16 },
  productCard: {
    width: '48%',
    backgroundColor: 'white',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    position: 'relative',
  },
  productImage: { width: '100%', height: 150, resizeMode: 'cover' },
  productInfo: { padding: 12, paddingBottom: 40 },
  productName: { fontSize: 16, fontWeight: '600', marginBottom: 4, color: '#333' },
  productPrice: { fontSize: 16, fontWeight: 'bold', color: '#2e86de', marginBottom: 8 },
  productDescription: { fontSize: 12, color: '#666', marginBottom: 8, paddingRight: 10 },
  addToCartButton: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    backgroundColor: '#2e86de',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2,
  },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

export default HomeScreen;