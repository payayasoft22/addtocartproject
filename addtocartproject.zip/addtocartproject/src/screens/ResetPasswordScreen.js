import React, { useEffect, useRef, useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Animated, 
  Easing 
} from 'react-native';

const PARTY_COLORS = [
  '#1A1A40',
  '#FF4500',
  '#FFD700',
  '#8A2BE2',
  '#00CED1',
  '#FF69B4',
  '#FFA500',
];

const TEXT_COLORS = [
  '#FFD700',
  '#FF4500',
  '#1A1A40',
  '#00CED1',
  '#FF69B4',
  '#8A2BE2',
  '#FFA500',
];

const EMOJIS = ['🎉', '🎊', '🥳'];

const ResetPasswordScreen = ({ navigation }) => {
  const bgColorAnim = useRef(new Animated.Value(0)).current;
  const textColorAnim = useRef(new Animated.Value(0)).current;
  const [emojiIndex, setEmojiIndex] = useState(0);

  useEffect(() => {
    // Animate background color in a loop - faster now
    Animated.loop(
      Animated.timing(bgColorAnim, {
        toValue: PARTY_COLORS.length - 1,
        duration: PARTY_COLORS.length * 1000, // half previous duration
        easing: Easing.linear,
        useNativeDriver: false,
      })
    ).start();

    // Animate text color in a loop - faster now
    Animated.loop(
      Animated.timing(textColorAnim, {
        toValue: TEXT_COLORS.length - 1,
        duration: TEXT_COLORS.length * 1000,
        easing: Easing.linear,
        useNativeDriver: false,
      })
    ).start();

    // Change emoji every 1.5 seconds cycling 3 emojis
    const emojiInterval = setInterval(() => {
      setEmojiIndex((prev) => (prev + 1) % EMOJIS.length);
    }, 1500);

    return () => clearInterval(emojiInterval);
  }, []);

  const backgroundColor = bgColorAnim.interpolate({
    inputRange: PARTY_COLORS.map((_, i) => i),
    outputRange: PARTY_COLORS,
  });

  const textColor = textColorAnim.interpolate({
    inputRange: TEXT_COLORS.map((_, i) => i),
    outputRange: TEXT_COLORS,
  });

  return (
    <Animated.View style={[styles.container, { backgroundColor }]}>
      <Animated.Text style={[styles.partyEmoji, { color: textColor }]}>
        {EMOJIS[emojiIndex]}
      </Animated.Text>
      <Animated.Text style={[styles.message, { color: textColor }]}>
        di pa tapos ayaw kase tomolong
      </Animated.Text>
      <TouchableOpacity 
        style={styles.button} 
        onPress={() => navigation.goBack()}
        activeOpacity={0.8}
      >
        <Text style={styles.buttonText}>Back to Login</Text>
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  partyEmoji: {
    fontSize: 72,
    marginBottom: 30,
    textShadowColor: '#00000099',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 8,
  },
  message: {
    fontSize: 24,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 40,
    textShadowColor: '#00000099',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 6,
  },
  button: {
    backgroundColor: '#FF4500',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    shadowColor: '#FF6347',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 10,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
});

export default ResetPasswordScreen;
